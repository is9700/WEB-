
// hichem
function Reservierung(anrede, Name, Nachname, Parkplatz_Nummer, tatigkeit, etage, strasse, hausnummer, Postleitzahl,
    ort, Nummer, email, KFZ,
    Anlass, MtrN, reservdate,
    Zeit, preis, Zahlungsmethode, abo_type, Nr, Abonnement) {

    this.anrede = anrede;
    this.Name = Name;
    this.Nachname = Nachname;
    this.hausnummer = hausnummer;
    this.Postleitzahl = Postleitzahl;
    this.ort = ort;
    this.email = email;
    this.Nummer = Nummer;
    this.KFZ = KFZ;
    this.etage = etage;
    this.Parkplatz_Nummer = Parkplatz_Nummer;
    this.Anlass = Anlass;
    this.MtrN = MtrN;
    this.tatigkeit = tatigkeit;
    this.reservdate = reservdate;
    this.preis = preis;
    this.Zeit = Zeit;
    this.strasse = strasse;
    this.Zahlungsmethode = Zahlungsmethode;
    this.abo_type = abo_type;
    this.Nr = Nr;
    this.Abonnement = Abonnement;

}




function Abonnement(anrede, Name, Nachname, strasse, hausnummer, Postleitzahl,
    ort, Nummer, email, KFZ, abonn,  abo_type, Geld ) {

    this.anrede = anrede;
    this.Name = Name;
    this.Nachname = Nachname;
    this.strasse = strasse;
    this.hausnummer = hausnummer;
    this.Postleitzahl = Postleitzahl;
    this.ort = ort;
    this.email = email;
    this.Nummer = Nummer;
    this.KFZ = KFZ; 
    this.abonn = abonn;
    this.abo_type = abo_type;
    this.Geld = Geld;

    
}


Abonnement.AddToListAbo = (obj) => {
    console.log(obj);
    AbonnementList.push(new Abonnement(
        obj.anrede, obj.name, obj.nachname,  obj.strasse, obj.hausnummer, obj.Postleitzahl,
        obj.ort, obj.Nummer, obj.email, obj.KFZ,
        obj.abonn,obj.abo_type, obj.Geld
        
    ));
}




Reservierung.AddToList = (obj) => {
    console.log(obj);
    ReservierungList.push(new Reservierung(
        obj.anrede, obj.name, obj.nachname, obj.Parkplatz_Nummer, obj.tatigkeit, obj.etage, obj.strasse, obj.hausnummer, obj.Postleitzahl,
        obj.ort, obj.Nummer, obj.email, obj.KFZ,
        obj.Anlass, obj.MtrN, obj.reservdate,
        obj.zeit, obj.preis, obj.Zahlungsmethode, obj.abo_type, obj.Nr, obj.Abonnement
    ));
}


Abonnement.getListAbo = () => {
    return AbonnementList;
}

Reservierung.getList = () => {
    return ReservierungList;
}


var AbonnementList = [];
AbonnementList.push(new Abonnement("Herr", "Mario", "Schmitt", "Brunnenstrasse", "37", "47587","Dortmund","01786736354","Mario@gmail.com","Do ER31","1-Monat-Abonnement","Privates Arbeitnehmer","Kreditkarte"));
AbonnementList.push(new Abonnement("Herr", "Mohammed", "Lasoued", "Hördestrasse", "33", "47958","Dortmund","01787732354","Hama@gmail.com","Do MO39","3-Monat-Abonnement","Privates Arbeitnehmer","PayPal"));
AbonnementList.push(new Abonnement("Frau", "Angelika", "Bussman", "Nussbaumstrasse", "65", "47522","Dortmund","01786736344","Ang@gmail.com","Do AN44","Jahresabonnement","Wohnsitze","Kreditkarte"));




var ReservierungList = [];
ReservierungList.push(new Reservierung("Herr", "Alex", "Schneider", "58", "Student", "EG","Hellweg","23","47586","Essen","9382","alex@yahoo.com","ES ER34","intern","78364736","12.03.2021","12:00,14:00","0","none","none","none","none"));
ReservierungList.push(new Reservierung("Herr", "Michel", "Rman", "54", "Student", "1UG","klosterstrasse","07","48736","Dortmund","9377","michel@gmail.com","DO DF77","intern","79837465","12.03.2021","08:00,12:00","0","none","none","none","none"));
ReservierungList.push(new Reservierung("Frau", "Lena", "Muller", "78", "Professor", "EG","fitnesstrasse","09","46736","Bochum","90384","lena@hotmail.com","BO LE39","intern","20394857","17.03.2021","09:00,14:00","0","none","none","none","none"));




module.exports.Reservierung = Reservierung;
module.exports.Abonnement = Abonnement;
